package com.example.greenlight;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ImageView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.json.*;
import java.util.*;
public class MainActivity extends AppCompatActivity {
    private String urlJour;
    private String urlHeure;
    private TextView situation0;
    private ImageView feu0;
    private ImageView i00, i01, i02, i03, i04, i05, i06, i07, i08, i09, i010, i011, i012, i013, i014, i015, i016, i017, i018, i019, i020, i021, i022, i023;
    private ExecutorService exe;
    private Future<String> todo;
    private Button bouton0;

    // Fonction pour lire un URL
    public Future<String> lireURL(URL u) {
        return exe.submit(() -> {
            URLConnection c;
            String inputline;
            StringBuilder codeHTML = new StringBuilder("");

            try {
                c = u.openConnection();
                //temps maximun alloué pour se connecter
                c.setConnectTimeout(60000);
                //temps maximun alloué pour lire
                c.setReadTimeout(10000);
                //flux de lecture avec l'encodage des caractères UTF-8
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(c.getInputStream(), "UTF-8"));
                while ((inputline = in.readLine()) != null) {
                    //concaténation+retour à la ligne avec \n
                    codeHTML.append(inputline + "\n");
                }
                //il faut bien fermer le flux de lecture
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return codeHTML.toString();
        });
    }

    // Fonction pour avoir le résultat de lireURL
    public String objetJSON(String s) {
        URL u;

        try {
            u = new URL(s);
        } catch (MalformedURLException e) {
            // Ce n'est qu'un exemple, pas de traitement propre de l'exception
            e.printStackTrace();
            u = null;
        }

        // On crée l'objet qui va gérer la thread
        exe = Executors.newSingleThreadExecutor();
        // On lance la thread
        todo = lireURL(u);
        // On attend le résultat
        try {
            s = todo.get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        // On affiche le résultat
        return s;
    }

    public void setJour(String n, ImageView feu, TextView situation) {
        String message;
        int dvalue;
        String jour;

        String sJour = objetJSON("http://isis.unice.fr/~cd006182/ext/GreenLight/Jour.php");
        jour = "Jour" + n;
        try {
            JSONObject json = new JSONObject(sJour);
            dvalue = json.getJSONObject(jour).getInt("dvalue");
            message = "";

            if (dvalue == 1) {
                message = "Situation normale";
                feu.setImageResource(R.drawable.feu_vert);
            }
            if (dvalue == 2) {
                message = "Situation tendue";
                feu.setImageResource(R.drawable.feu_orange);
            }
            if (dvalue == 3) {
                message = "Situation très tendue";
                feu.setImageResource(R.drawable.feu_rouge);
            };
            situation.setText(message);
        }
        catch (JSONException e) {
            System.err.println(e);
        }
    }


    public void setHeure(String n, ImageView[] carre) {
        int hvalue;
        String jour;
        int nbValeurs;
        ImageView icarre;

        String sHeure = objetJSON("http://isis.unice.fr/~cd006182/ext/GreenLight/Heure.php");
        System.out.println(carre);
        jour = "Jour" + n;
        try {
            JSONObject json = new JSONObject(sHeure);
            System.out.println("boucle");
            nbValeurs = json.getJSONObject(jour).getInt("nbValeurs");
            System.out.println(nbValeurs);

            for (int i = (24 - nbValeurs); i < 24 ; i++) {
                hvalue = json.getJSONObject(jour).getInt(Integer.toString(i));
                System.out.println(i + " : " + hvalue);
                icarre = carre[i];
                System.out.println(icarre);
                if (hvalue == 1) {
                    icarre.setImageResource(R.drawable.green);
                }
                if (hvalue == 2) {
                    icarre.setImageResource(R.drawable.orange);
                }
                if (hvalue == 3) {
                    icarre.setImageResource(R.drawable.red);
                }
            }
        }
        catch (JSONException e) {
            System.err.println(e);
        }
        System.out.println("okokokok");
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Cette directive enlève la barre de titre
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        // Cette directive permet d'enlever la barre de notifications pour afficher l'application en plein écran
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //On définit le contenu de la vue APRES les instructions précédentes pour éviter un crash
        this.setContentView(R.layout.activity_main);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.bouton0 = (Button) findViewById(R.id.bouton0);

        bouton0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent otherActivity = new Intent(getApplicationContext(), MainActivity2.class);
                startActivity(otherActivity);
                finish();

            }
        });

        situation0 = findViewById(R.id.situation0);
        feu0 = findViewById(R.id.feu0);

        // On modifie les données en fonction du jour
        setJour("0", feu0, situation0);

        // On fait le lien avec chaque pastille qui représente les heures
        // J-0
        i00 = findViewById(R.id.i00); i01 = findViewById(R.id.i01); i02 = findViewById(R.id.i02); i03 = findViewById(R.id.i03); i04 = findViewById(R.id.i04);
        i05 = findViewById(R.id.i05); i06 = findViewById(R.id.i06); i07 = findViewById(R.id.i07); i08 = findViewById(R.id.i08); i09 = findViewById(R.id.i09);
        i010 = findViewById(R.id.i010); i011 = findViewById(R.id.i011); i012 = findViewById(R.id.i012); i013 = findViewById(R.id.i013); i014 = findViewById(R.id.i014);
        i015 = findViewById(R.id.i015); i016 = findViewById(R.id.i016); i017 = findViewById(R.id.i017); i018 = findViewById(R.id.i018); i019 = findViewById(R.id.i019);
        i020 = findViewById(R.id.i020); i021 = findViewById(R.id.i021); i022 = findViewById(R.id.i022); i023 = findViewById(R.id.i023);

        ImageView[] listeHeure0 = {i00, i01, i02, i03, i04, i05, i06, i07, i08, i09, i010, i011, i012, i013, i014, i015, i016, i017, i018, i019, i020, i021, i022, i023};

        // On modifie les données en fonction de l'heure
        setHeure("0", listeHeure0);
    }
}