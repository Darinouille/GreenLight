package com.example.greenlight;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ImageView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.json.*;
import java.util.*;
public class MainActivity2 extends AppCompatActivity {

    private TextView situation1;
    private ImageView feu1;

    private TextView situation2;
    private ImageView feu2;

    private TextView situation3;
    private ImageView feu3;

    private ImageView i0, i1, i2, i3, i4, i5, i6, i7, i8, i9, i10, i11, i12, i13, i14, i15, i16, i17, i18, i19, i20, i21, i22, i23;
    private ImageView ii0, ii1, ii2, ii3, ii4, ii5, ii6, ii7, ii8, ii9, ii10, ii11, ii12, ii13, ii14, ii15, ii16, ii17, ii18, ii19, ii20, ii21, ii22, ii23;
    private ImageView iii0, iii1, iii2, iii3, iii4, iii5, iii6, iii7, iii8, iii9, iii10, iii11, iii12, iii13, iii14, iii15, iii16, iii17, iii18, iii19, iii20, iii21, iii22, iii23;
    private Button bouton1;

    private String urlJour;
    private String urlHeure;

    private ExecutorService exe;
    private Future<String> todo;

    // Fonction pour lire un URL
    public Future<String> lireURL(URL u) {
        return exe.submit(() -> {
            URLConnection c;
            String inputline;
            StringBuilder codeHTML = new StringBuilder("");

            try {
                c = u.openConnection();
                //temps maximun alloué pour se connecter
                c.setConnectTimeout(60000);
                //temps maximun alloué pour lire
                c.setReadTimeout(10000);
                //flux de lecture avec l'encodage des caractères UTF-8
                BufferedReader in = new BufferedReader(
                        new InputStreamReader(c.getInputStream(), "UTF-8"));
                while ((inputline = in.readLine()) != null) {
                    //concaténation+retour à la ligne avec \n
                    codeHTML.append(inputline + "\n");
                }
                //il faut bien fermer le flux de lecture
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return codeHTML.toString();
        });
    }

    // Fonction pour avoir le résultat de lireURL
    public String objetJSON(String s) {
        URL u;

        try {
            u = new URL(s);
        } catch (MalformedURLException e) {
            // Ce n'est qu'un exemple, pas de traitement propre de l'exception
            e.printStackTrace();
            u = null;
        }

        // On crée l'objet qui va gérer la thread
        exe = Executors.newSingleThreadExecutor();
        // On lance la thread
        todo = lireURL(u);
        // On attend le résultat
        try {
            s = todo.get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        // On affiche le résultat
        return s;
    }

    public void setJour(String n, ImageView feu, TextView situation) {
        String message;
        int dvalue;
        String jour;

        String sJour = objetJSON("http://isis.unice.fr/~cd006182/ext/GreenLight/Jour.php");
        jour = "Jour" + n;
        try {
            JSONObject json = new JSONObject(sJour);
            dvalue = json.getJSONObject(jour).getInt("dvalue");
            message = "";

            if (dvalue == 1) {
                message = "Situation normale";
                feu.setImageResource(R.drawable.feu_vert);
            }
            if (dvalue == 2) {
                message = "Situation tendue";
                feu.setImageResource(R.drawable.feu_orange);
            }
            if (dvalue == 3) {
                message = "Situation très tendue";
                feu.setImageResource(R.drawable.feu_rouge);
            }
            situation.setText(message);
        }
        catch (JSONException e) {
            System.err.println(e);
        }
    }

    public void setHeure(String n, ImageView[] carre) {
        int hvalue;
        String jour;
        int nbValeurs;
        ImageView icarre;

        String sHeure = objetJSON("http://isis.unice.fr/~cd006182/ext/GreenLight/Heure.php");
        System.out.println(carre);
        jour = "Jour" + n;
        try {
            JSONObject json = new JSONObject(sHeure);
            System.out.println(json);
            nbValeurs = json.getJSONObject(jour).getInt("nbValeurs");
            System.out.println(nbValeurs);

            for (int i = (24 - nbValeurs); i < 24 ; i++) {
                hvalue = json.getJSONObject(jour).getInt(Integer.toString(i));
                icarre = carre[i];
                System.out.println(icarre);
                System.out.println(i + " : " + hvalue);
                icarre = carre[i];
                System.out.println(icarre);
                if (hvalue == 1) {
                    icarre.setImageResource(R.drawable.green);
                }
                if (hvalue == 2) {
                    icarre.setImageResource(R.drawable.orange);
                }
                if (hvalue == 3) {
                    icarre.setImageResource(R.drawable.red);
                }
            }
        }
        catch (JSONException e) {
            System.err.println(e);
        }
        System.out.println("okokokok");
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Cette directive enlève la barre de titre
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        // Cette directive permet d'enlever la barre de notifications pour afficher l'application en plein écran
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //On définit le contenu de la vue APRES les instructions précédentes pour éviter un crash
        this.setContentView(R.layout.activity_main);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        this.bouton1 = (Button) findViewById(R.id.bouton1);

        bouton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent otherActivity = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(otherActivity);
                finish();
            }
        });

        // On modifie les données en fonction du jour
        //J+1
        situation1 = findViewById(R.id.situation1);
        feu1 = findViewById(R.id.feu1);
        setJour("1", feu1, situation1);

        //J+2
        situation2 = findViewById(R.id.situation2);
        feu2 = findViewById(R.id.feu2);
        setJour("2", feu2, situation2);

        //J+3
        situation3 = findViewById(R.id.situation3);
        feu3 = findViewById(R.id.feu3);
        setJour("3", feu3, situation3);

        // On fait le lien avec chaque pastille qui représente les heures
        // J+1
        i0 = findViewById(R.id.i0); i1 = findViewById(R.id.i1); i2 = findViewById(R.id.i2); i3 = findViewById(R.id.i3); i4 = findViewById(R.id.i4);
        i5 = findViewById(R.id.i5); i6 = findViewById(R.id.i6); i7 = findViewById(R.id.i7); i8 = findViewById(R.id.i8); i9 = findViewById(R.id.i9);
        i10 = findViewById(R.id.i10); i11 = findViewById(R.id.i11); i12 = findViewById(R.id.i12); i13 = findViewById(R.id.i13); i14 = findViewById(R.id.i14);
        i15 = findViewById(R.id.i15); i16 = findViewById(R.id.i16); i17 = findViewById(R.id.i17); i18 = findViewById(R.id.i18); i19 = findViewById(R.id.i19);
        i20 = findViewById(R.id.i20); i21 = findViewById(R.id.i21); i22 = findViewById(R.id.i22); i23 = findViewById(R.id.i23);

        ImageView[] listeHeure1 = {i0, i1, i2, i3, i4, i5, i6, i7, i8, i9, i10, i11, i12, i13, i14, i15, i16, i17, i18, i19, i20, i21, i22, i23};

        // J+2
        ii0 = findViewById(R.id.ii0); ii1 = findViewById(R.id.ii1); ii2 = findViewById(R.id.ii2); ii3 = findViewById(R.id.ii3); ii4 = findViewById(R.id.ii4);
        ii5 = findViewById(R.id.ii5); ii6 = findViewById(R.id.ii6); ii7 = findViewById(R.id.ii7); ii8 = findViewById(R.id.ii8); ii9 = findViewById(R.id.ii9);
        ii10 = findViewById(R.id.ii10); ii11 = findViewById(R.id.ii11); ii12 = findViewById(R.id.ii12); ii13 = findViewById(R.id.ii13); ii14 = findViewById(R.id.ii14);
        ii15 = findViewById(R.id.ii15); ii16 = findViewById(R.id.ii16); ii17 = findViewById(R.id.ii17); ii18 = findViewById(R.id.ii18); ii19 = findViewById(R.id.ii19);
        ii20 = findViewById(R.id.ii20); ii21 = findViewById(R.id.ii21); ii22 = findViewById(R.id.ii22); ii23 = findViewById(R.id.ii23);

        ImageView[] listeHeure2 = {ii0, ii1, ii2, ii3, ii4, ii5, ii6, ii7, ii8, ii9, ii10, ii11, ii12, ii13, ii14, ii15, ii16, ii17, ii18, ii19, ii20, ii21, ii22, ii23};

        // J+3
        iii0 = findViewById(R.id.iii0); iii1 = findViewById(R.id.iii1); iii2 = findViewById(R.id.iii2); iii3 = findViewById(R.id.iii3); iii4 = findViewById(R.id.iii4);
        iii5 = findViewById(R.id.iii5); iii6 = findViewById(R.id.iii6); iii7 = findViewById(R.id.iii7); iii8 = findViewById(R.id.iii8); iii9 = findViewById(R.id.iii9);
        iii10 = findViewById(R.id.iii10); iii11 = findViewById(R.id.iii11); iii12 = findViewById(R.id.iii12); iii13 = findViewById(R.id.iii13); iii14 = findViewById(R.id.iii14);
        iii15 = findViewById(R.id.iii15); iii16 = findViewById(R.id.iii16); iii17 = findViewById(R.id.iii17); iii18 = findViewById(R.id.iii18); iii19 = findViewById(R.id.iii19);
        iii20 = findViewById(R.id.iii20); iii21 = findViewById(R.id.iii21); iii22 = findViewById(R.id.iii22); iii23 = findViewById(R.id.iii23);

        ImageView[] listeHeure3 = {iii0, iii1, iii2, iii3, iii4, iii5, iii6, iii7, iii8, iii9, iii10, iii11, iii12, iii13, iii14, iii15, iii16, iii17, iii18, iii19, iii20, iii21, iii22, iii23};
        // On modifie les données en fonction de l'heure
        setHeure("1", listeHeure1);
        setHeure("2", listeHeure2);
        setHeure("3", listeHeure3);
    }
}